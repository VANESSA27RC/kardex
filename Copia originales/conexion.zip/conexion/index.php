<html>
<head>
	<title>Sistema de Compras y Ventas</title>
	<link rel='stylesheet' type='text/css' href='./css/styles.css'>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
</head>

<center>
<table width="800" border="0" align="center" cellpadding="0" cellspacing="0">
<tr>
	<td width="100%" bgcolor="#FF9900">
		<br>
		<?php
		require('x_encabezado.php');
		?>
		<br>
	</td>
</tr>
<tr>
	<td width="100%" height="100%" valign="top">
		<br>
		<br>

		<!-- Cuerpo de la página -->
		<table width="100%" border="0" cellpadding="10" cellspacing="0" bgcolor="#FFFFFF">
		<tr>
			<td colspan="2" align="center">
				<h1>GESTION DE COMPRAS Y VENTAS</h1>
			</td>
		</tr>
		<tr>
			<td width="60%">
				kj sadfjhgsdfhshdf jhsad fjhsa dhj sjgfshagd hjg sadfhg jsdhf jhgsad fh sgf 
				k sjlijwe rpweojh qipjcn isand ciuqw cuin qwciu wqiuc bwqunc9uw e9uhwq efiun we9fu h
				po iwjfjoh wqeopfi wqoeihf oiwqhe roihwq eofiwq eoifh owqeihfopiwqhefoi wqefopihw 
				eopfhowiehf. 
				<br>
				<br>
				Esperamos que sea de su interés y ayuda.
			</td>
			<td width="40%" align="center" valign="middle">
				<img src="images/estadisticas.jpg" width="273" height="185">			</td>
		</tr>
		<tr>
			<td colspan="2" align="center">

				<br>
				<br>

				<?php
				require('x_menu.php');
				?>

				<br>
				<br>

			</td>
		</tr>
		</table>
		<!-- FIN - Cuerpo de la página -->

		<br>
		<br>
	</td>
</tr>
<tr>
	<td width="100%" bgcolor="#FF9900">
		<?php
		require('x_pie.php');
		?>
	</td>
</tr>
</table>	
</center>
</body>
</html>
