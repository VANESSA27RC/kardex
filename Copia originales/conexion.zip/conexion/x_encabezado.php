<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
<tr>
	<td width="100%" align="center">
		<img src="images/banner1.jpg" width="800" height="200">
	</td>
</tr>
</table>	
