<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<table width="90%" border="0" cellspacing="10" cellpadding="10" align="center">
<tr>
	<td align="center" valign="middle">Inicio</td>
	<td align="center" valign="middle">Estadísticas generales</td>
	<td align="center" valign="middle">Compras/Ventas por producto</td>
	<td align="center" valign="middle">Compras/Ventas por fecha</td>
</tr>
</table>
