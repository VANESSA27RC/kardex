<html>
<head>
	<title>Sistema de Compras y Ventas</title>
	<link rel='stylesheet' type='text/css' href='./css/styles.css'>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
</head>
<body>

<center>
<table width="800" border="0" align="center" cellpadding="0" cellspacing="0">
<tr>
	<td width="100%" bgcolor="#FF9900">
		<br>
		<?php
		require('x_encabezado.php');
		?>
		<br>
	</td>
</tr>
<tr>
	<td width="100%" height="100%" valign="top">
		<br>
		<br>

		<!-- Cuerpo de la página -->
		<table width="100%" border="0" cellpadding="10" cellspacing="0" bgcolor="#FFFFFF">
		<tr>
			<td colspan="2" align="center">
				<h1>ESTADÍSTICAS GENERALES</h1>
				<?php
				require('x_menu.php');
				?>
			</td>
		</tr>
		<tr>
			<td colspan="2" align="center">

				<br>
				<br>

				<!-- Tabla de salida -->
				***
				<!-- FIN - Tabla de salida -->

			</td>
		</tr>
		</table>
		<!-- FIN - Cuerpo de la página -->

		<br>
		<br>
	</td>
</tr>
<tr>
	<td width="100%" bgcolor="#FF9900">
		<?php
		require('x_pie.php');
		?>
	</td>
</tr>
</table>	
</center>
</body>
</html>
